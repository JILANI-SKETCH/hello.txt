export interface Student {
  id: string;
  name: string;
  course: string;
  createdAt: string;
}

export interface StudentFormData {
  name: string;
  course: string;
}
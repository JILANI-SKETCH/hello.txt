import { Student } from '../types/Student';

const STORAGE_KEY = 'students';

export const getStudents = (): Student[] => {
  try {
    const stored = localStorage.getItem(STORAGE_KEY);
    return stored ? JSON.parse(stored) : [];
  } catch (error) {
    console.error('Error reading from localStorage:', error);
    return [];
  }
};

export const saveStudents = (students: Student[]): void => {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
  } catch (error) {
    console.error('Error saving to localStorage:', error);
  }
};

export const addStudent = (studentData: { name: string; course: string }): Student => {
  const students = getStudents();
  const newStudent: Student = {
    id: generateStudentId(),
    name: studentData.name.trim(),
    course: studentData.course.trim(),
    createdAt: new Date().toISOString(),
  };
  
  students.push(newStudent);
  saveStudents(students);
  return newStudent;
};

export const updateStudent = (id: string, updates: Partial<Pick<Student, 'name' | 'course'>>): boolean => {
  const students = getStudents();
  const index = students.findIndex(student => student.id === id);
  
  if (index === -1) return false;
  
  students[index] = {
    ...students[index],
    ...updates,
    name: updates.name?.trim() || students[index].name,
    course: updates.course?.trim() || students[index].course,
  };
  
  saveStudents(students);
  return true;
};

export const deleteStudent = (id: string): boolean => {
  const students = getStudents();
  const filteredStudents = students.filter(student => student.id !== id);
  
  if (filteredStudents.length === students.length) return false;
  
  saveStudents(filteredStudents);
  return true;
};

const generateStudentId = (): string => {
  const existingStudents = getStudents();
  const existingIds = existingStudents.map(s => parseInt(s.id)).filter(id => !isNaN(id));
  const maxId = existingIds.length > 0 ? Math.max(...existingIds) : 0;
  return String(maxId + 1).padStart(4, '0');
};